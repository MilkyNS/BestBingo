<script>
    let numbersRaffled = [];
    let ambo = [];
    let terna = [];
    let quaterna = [];
    let cinquina = [];


    function Raffle() {

        //Random Number created from 1 to 90
        let randomNumber = Math.floor(Math.random() * 90) + 1;
        while (
            numbersRaffled.includes(randomNumber) &&
            numbersRaffled.length <= 90
        ) {
            randomNumber = Math.floor(Math.random() * 90) + 1;
        }

        numbersRaffled = [...numbersRaffled, randomNumber];

        //Creation of an Array to check and split numbers divided by 10 and fix accordingly
        let listToUpdate;

        if (randomNumber % 10 == 0) {
            listToUpdate = numbersRaffled.filter(
                (number) => number <= randomNumber && number > randomNumber - 10
            );
        } else {
            listToUpdate = numbersRaffled.filter(
                (number) =>
                    number < Math.floor(randomNumber / 10) * 10 + 10 &&
                    number > Math.floor(randomNumber / 10) * 10
            );
        }

        // Checking for possible ambo, terna etc and update the Array
        if (ambo.length == 0 && listToUpdate.length == 2) {
            ambo = listToUpdate;
        } else if (terna.length == 0 && listToUpdate.length == 3) {
            terna = listToUpdate;
        } else if (quaterna.length == 0 && listToUpdate.length == 4) {
            quaterna = listToUpdate;
        } else if (cinquina.length == 0 && listToUpdate.length == 5) {
            cinquina = listToUpdate;
        }
    }

    // Reset button = clears all the arrays
    function Reset() {
        numbersRaffled = [];
        ambo = [];
        terna = [];
        quaterna = [];
        cinquina = [];
    }
</script>

<header>
    <h1 class="title">THE BEST BINGO</h1>
</header>

<div class="container">
    <div>
        <table id="content">
            {#each Array.from(Array(90 + 1).keys()).slice(1) as i}
                {#if numbersRaffled.includes(i)}
                    <td class="isRaffled">{i}</td>
                {:else}
                    <td class="notRaffled">{i}</td>
                {/if}
                {#if i % 10 === 0}
                    <tr />
                {/if}
            {/each}
        </table>
    </div>

    <div id="buttons">
        <button
            class="button-62"
            id="raffle"
            on:click={Raffle}
            disabled={cinquina.length != 0}>Raffle</button>
            
        <button class="button-62" id="reset" on:click={Reset}>Reset</button>
        <div class="punto">
            <span>AMBO: {ambo}</span>
            <br />
            <span>TERNA: {terna}</span>
            <br />
            <span>QUATERNA: {quaterna}</span>
            <br />
            <span>CINQUINA: {cinquina}</span>
        </div>
</div>
</div>
<style>
    @import url("https://fonts.googleapis.com/css2?family=Roboto&display=swap");

    header {
        background: linear-gradient(to bottom right, #ef4765, #ff9a5a);
        height: 4em;
        padding: 10px;
        text-align: center;
        width: 100%;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
    }
    .title {
        text-align: center;
        color: whitesmoke;
        font-family: "Roboto", sans-serif;
        font-weight: bolder;
    }
    .container {
        display: flex;
    }


    #buttons {
        margin-top: auto;
        margin-right: auto;
        margin-left: auto;
        padding-right: 10em;
        padding-bottom: 10em;
    }
    .button-62 {
        background: linear-gradient(to bottom right, #ef4765, #ff9a5a);
        border: 0;
        border-radius: 12px;
        color: #ffffff;
        cursor: pointer;
        font-family: "Roboto", sans-serif;
        font-size: 16px;
        font-weight: 500;
        line-height: 2.5;
        outline: transparent;
        padding: 0 2rem;
        text-align: center;
        text-decoration: none;
        transition: box-shadow 0.2s ease-in-out;
        user-select: none;
        -webkit-user-select: none;
        touch-action: manipulation;
        white-space: nowrap;
    }

    .button-62:not([disabled]):focus {
        box-shadow: 0 0 0.25rem rgba(0, 0, 0, 0.5),
            -0.125rem -0.125rem 1rem #ef476580,
            0.125rem 0.125rem 1rem rgba(255, 154, 90, 0.5);
    }

    .button-62:not([disabled]):hover {
        box-shadow: 0 0 0.25rem rgba(0, 0, 0, 0.5),
            -0.125rem -0.125rem 1rem #ef476580,
            0.125rem 0.125rem 1rem rgba(255, 154, 90, 0.5);
    }

    .isRaffled {
        background: #fc7250;
        box-shadow: 1px 2px #901d00;
    }
    .notRaffled {
        color: black;
    }

    .punto {
        font-family: "Roboto", sans-serif;
        padding-top: 5em;
        font-size: large;
        border-bottom: 2px solid #060606;
    }

    #raffle {
        margin-right: 2em;
    }
    #content {
        margin-top: 15em;
        margin-left: 2em;
        margin-right: auto;

        border-collapse: collapse;
        font-size: 0.9em;
        font-family: "Roboto", sans-serif;
        min-width: 400px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    td {
        padding: 12px 25px;
        text-align: center;
    }

    tr {
        border-bottom: 1px solid #dddddd;
    }

    tr:nth-of-type(even) {
        background-color: #f3f3f3;
    }

</style>
